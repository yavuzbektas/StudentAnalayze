
from django import forms
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.http import HttpResponse

from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _




    
def validate_evenz(value):
    y=str(value)
    x=list(y)
        
        
    if len(x) != 10 :
        raise ValidationError(
            _('%(value)s 10 basasmaklı olmalı'),
            params={'value': value},
        )




def validate_even(value):
    y=str(value)
    x=list(y)
        
        
    if len(x) != 11:
        raise ValidationError(
            _('%(value)s 11 basasmaklı olmalı'),
            params={'value': value},
        )
def index(request):

    return render(request,'polls/index.html')
def detail(request, question_id):
    return HttpResponse("You're looking at question %s." % question_id)

def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)

def vote(request, question_id):
    return HttpResponse("You're voting on question %s." % question_id)